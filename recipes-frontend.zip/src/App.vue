<template>
  <router-view />
</template>

<script setup lang="ts">
</script>

<style>
body {
  font-family: sans-serif;
  margin: 0;
  padding: 0;
}
</style>
